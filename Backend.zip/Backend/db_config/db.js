// // src/db.js
// const { Pool } = require("pg");
// const dotenv = require("dotenv");

// dotenv.config();

// const pool = new Pool({
//   user: process.env.DB_USER,
//   host: process.env.DB_HOST,
//   database: process.env.DB_NAME,
//   password: process.env.DB_PASSWORD,
//   port: process.env.DB_PORT,
// });

// module.exports = pool;

const { Pool } = require("pg");

// Directly use the connection string for Render
const pool = new Pool({
  connectionString:
    "postgresql://productmanagement_p05a_user:d20jPJ2iuFybwGaKkHjdYujuWSTKgufs@dpg-cse9kirtq21c73874gog-a.oregon-postgres.render.com:5432/productmanagement_p05a",
  ssl: { rejectUnauthorized: false }, // Set SSL configuration
});

// Test the database connection
pool.query("SELECT NOW()", (err, res) => {
  if (err) {
    console.error("Error connecting to the database:", err.stack);
  } else {
    console.log("Connected to the database successfully at:", res.rows[0].now);
  }
  // Close the pool after testing
  pool.end();
});
